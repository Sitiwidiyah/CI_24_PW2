</div>
</div>
</div>

<script src="<?= base_url('assets/vendor/jquery/jquery/min.js');?>"></script>
<script src="<?= base_url('assets/vendor/bootsrap.bundle.min.js');?>"></script>
<script src="<?= base_url('assets/js/sb-admin-2.min.js');?>"></script>

</body>
</html>